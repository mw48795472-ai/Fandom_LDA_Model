# v6_r22_era 백업 — 특이사항 메모 (2026-09-22)

이 압축 파일은 최종 코퍼스(10,020건) 확정 이전, v7 라운드22 시점(근거문장 5,612건, LDA K=8·M=6·실루엣 0.154)의 자료 일체다.
저장소 본문은 최종 데이터셋 기준으로만 서술하므로 이 폴더는 저장소에서 제거했고, 만일의 대조용으로 압축본만 남긴다.

## 내용
- data/v6_r22_snapshot/: r22 코퍼스 fandoms_v3_100.json(5,612건), fandom_scores_v6.json/.csv(M=6), lda_v6_diagnostics.json, chart3d_payload_v6.json,
  v7_progress.json(r22), domestic_regional_pilot_v6.json, member_mention_pilot_v6.json(23개 그룹), csv/(평탄화·성장이력·K-grid·지역·멤버 CSV)
- 파일럿 문서·노트북 6종(광고·결속·미디어·국내지역·세계언어·그룹멤버), fan_impact_ontology/, TOKENIZER/(스크립트 3종·문서 2종),
  TOKENIZER_WORDCLOUD_REPORT/tokenizer_script_routing_pilot.ipynb, 상세명세서/LDA_V6_V7_TECHNICAL_SPECIFICATION.md
- 노트북은 `../data/v6_r22_snapshot` 상대경로를 읽으므로 압축을 그대로 풀면 동작한다.

## 특이사항
1. r22 병합 로그(merge_log_r22.json)의 after_total은 5,613이지만 실제 코퍼스 평탄화는 5,612건이다(기록상 +1 오차).
2. domestic_regional_pilot_v6.json은 마지막 병합 직전에 생성돼, 코퍼스에 실재하는 "강원 평창"(로이킴)·"강원 영월군"(빅뱅) 2셀이 0으로 남아 있다.
3. r22 코퍼스에는 URL 필드에 세션 도구 문구("agentId: …")가 섞인 불릿 5건과 URL 없는 참고문구 불릿 64건이 있었다(최종 코퍼스에서는 0건).
4. 언어 커버리지는 10개 언어·분모 ln(10) 기준이라 최종(14개 언어, ln 14)·동결(13개, ln 13) 값과 절대치 비교가 불가하다.
5. TOKENIZER/jieba_and_thai_engine_details.py는 script_of()가 main() 안에 정의돼 import가 실패한다(최종판 스크립트에서 수정).
6. 로스터가 최종과 다르다: r22에는 pH-1·창모·사이먼도미닉·BE'O·헤이즈·한로로가 있고 GOT7·김재중·박서진·빈지노·몬스타엑스·투어스(TWS)가 없다.
